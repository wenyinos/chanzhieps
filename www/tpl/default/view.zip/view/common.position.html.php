<div class='row'><div class='u-1'><?php $common->printPositionBar();?></div></div>
