<?php RUN_MODE == 'front' ? include 'login.front.html.php' : include 'login.admin.html.php';?>
